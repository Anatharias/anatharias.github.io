import asyncio
import json
import os
import pwd
import re
import shutil
import signal
import struct
import urllib.parse
import zipfile
from pathlib import Path
from typing import Any


import decky


class Plugin:
    MODULE_FILE = "cpuid_fault_emulation.ko"
    MODULE_NAME = "cpuid_fault_emulation"
    RELEASE_API_URL = (
        "https://api.github.com/repos/2804u13j200-spec/glowing-tribble/releases/latest"
    )
    JUPITER_REPOSITORY_FALLBACK = (
        "https://steamdeck-packages.steamos.cloud/"
        "archlinux-mirror/jupiter-3.8/os/x86_64/"
    )

    def __init__(self) -> None:
        self._operation_lock = asyncio.Lock()
        self._last_log = ""
        self._watcher_module_path: Path | None = None
        self._watcher_module_name: str | None = None
        self._running_game_ids: set[str] = set()
        self._running_game_instances: dict[str, set[int]] = {}

    @property
    def plugin_dir(self) -> Path:
        configured = getattr(decky, "DECKY_PLUGIN_DIR", None)
        return Path(configured) if configured else Path(__file__).resolve().parent

    @property
    def settings_path(self) -> Path:
        configured = getattr(decky, "DECKY_SETTINGS_DIR", None)
        root = Path(configured) if configured else self.plugin_dir
        return root / "hypervisor-manager.json"

    @property
    def config(self) -> dict[str, Any]:
        default_home = getattr(decky, "DECKY_USER_HOME", "/home/deck")
        defaults = {
            "source_dir": str(default_home),
            "compiler": "auto",
            "make_args": [],
            "module_parameters": [],
            "game_hv": {},
            "shortcuts_file": "",
            "native_cpuid_check_complete": False,
            "native_cpuid_supported": None,
            "native_cpuid_output": "",
            "native_cpuid_notice_dismissed": False,
        }
        try:
            value = json.loads(self.settings_path.read_text(encoding="utf-8"))
            return {**defaults, **value} if isinstance(value, dict) else defaults
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return defaults

    @property
    def source_dir(self) -> Path:
        return Path(str(self.config["source_dir"])).expanduser().resolve()

    def _save_config(self, settings: dict[str, Any]) -> None:
        self.settings_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.settings_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(settings, indent=2) + "\n", encoding="utf-8"
        )
        temporary.replace(self.settings_path)

    async def _probe_cpuid_faulting(self) -> dict[str, Any]:
        probe = self.plugin_dir / "py_modules" / "cpuid_fault_probe.py"
        if not probe.is_file():
            return {
                "working": False,
                "available": None,
                "message": "The CPUID faulting probe is missing.",
            }

        python = next(
            (
                str(candidate)
                for candidate in (Path("/usr/bin/python3"), Path("/usr/bin/python"))
                if candidate.is_file()
            ),
            None,
        )
        if python is None:
            return {
                "working": False,
                "available": None,
                "message": "A system Python interpreter is required for the CPUID probe.",
            }

        environment = os.environ.copy()
        environment.pop("LD_LIBRARY_PATH", None)
        environment.pop("LD_PRELOAD", None)
        process = await asyncio.create_subprocess_exec(
            python,
            str(probe),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            env=environment,
        )
        stdout, _ = await process.communicate()
        returncode = process.returncode
        output = stdout.decode("utf-8", errors="replace").strip()
        if returncode == 0:
            return {
                "working": True,
                "available": True,
                "output": output,
                "message": (
                    "CPUID faulting is working: leaf 0x336933 faulted and "
                    "the SIGSEGV handler resumed execution with EAX=0x1337."
                ),
            }
        if returncode == 2:
            return {
                "working": False,
                "available": False,
                "output": output,
                "message": "ARCH_SET_CPUID is not supported.",
            }
        if returncode == 3:
            return {
                "working": False,
                "available": True,
                "output": output,
                "message": (
                    "ARCH_SET_CPUID succeeded, but the diagnostic CPUID "
                    "instruction did not fault."
                ),
            }
        if returncode == 5:
            return {
                "working": False,
                "available": True,
                "output": output,
                "message": "The SIGSEGV handler received an unexpected fault.",
            }
        if returncode == 6:
            return {
                "working": False,
                "available": True,
                "output": output,
                "message": "The SIGSEGV handler could not be installed.",
            }
        if returncode in (1, 7):
            detail = output[-4000:] if output else "No traceback was produced."
            return {
                "working": False,
                "available": None,
                "output": output,
                "message": f"The CPUID faulting probe failed:\n{detail}",
            }
        if returncode == -signal.SIGSEGV:
            return {
                "working": False,
                "available": True,
                "output": output,
                "message": "CPUID faulted, but the SIGSEGV handler did not recover.",
            }
        if returncode == 4:
            return {
                "working": False,
                "available": False,
                "output": output,
                "message": "CPUID faulting can only be tested on x86-64.",
            }
        return {
            "working": False,
            "available": None,
            "output": output,
            "message": (
                f"The CPUID faulting probe exited unexpectedly ({returncode})."
                + (f"\n{output[-4000:]}" if output else "")
            ),
        }

    async def test_cpuid_faulting(self) -> dict[str, Any]:
        async with self._operation_lock:
            result = await self._probe_cpuid_faulting()
            self._last_log = result["message"]
            return await self._result(
                result["working"],
                result["message"],
                result.get("output", ""),
            )

    async def get_native_cpuid_notice(self) -> dict[str, Any]:
        settings = self.config
        if settings.get("native_cpuid_check_complete"):
            supported = settings.get("native_cpuid_supported") is True
            return {
                "show": (
                    supported
                    and not bool(settings.get("native_cpuid_notice_dismissed"))
                ),
                "message": (
                    "This CPU supports CPUID faulting natively. "
                    "The HV module is not required. "
                    "You may still need to disable UMIP. "
                ),
                "output": str(settings.get("native_cpuid_output", "")),
            }

        if self.MODULE_NAME in self._loaded_modules():
            return {"show": False, "message": "", "output": ""}

        async with self._operation_lock:
            result = await self._probe_cpuid_faulting()
        if result["available"] is not None:
            settings = self.config
            settings["native_cpuid_check_complete"] = True
            settings["native_cpuid_supported"] = result["working"]
            settings["native_cpuid_output"] = result.get("output", "")
            self._save_config(settings)

        supported = result["working"]
        return {
            "show": supported,
            "message": (
                "This CPU supports CPUID faulting natively. "
                "The emulation module is not required."
            ) if supported else result["message"],
            "output": result.get("output", ""),
        }

    async def dismiss_native_cpuid_notice(self) -> None:
        settings = self.config
        settings["native_cpuid_notice_dismissed"] = True
        self._save_config(settings)

    @property
    def automatic_module_dir(self) -> Path:
        return self.plugin_dir / "downloaded-modules"

    @property
    def automatic_module_path(self) -> Path:
        return self.automatic_module_dir / self.MODULE_FILE

    async def set_source_directory(self, path: str) -> dict[str, Any]:
        candidate = Path(path).expanduser().resolve()
        if not candidate.is_dir():
            raise ValueError("The selected path is not a directory.")
        if not (candidate / "Makefile").is_file():
            raise ValueError("The selected directory does not contain a Makefile.")

        settings = self.config
        settings["source_dir"] = str(candidate)
        self._save_config(settings)
        self._last_log = f"Selected hypervisor directory: {candidate}"
        return await self.get_status()

    async def set_source_zip(self, path: str) -> dict[str, Any]:
        archive = Path(path).expanduser().resolve()
        if not archive.is_file() or archive.suffix.lower() != ".zip":
            raise ValueError("The selected path is not a ZIP file.")

        extraction_dir = self.settings_path.parent / "hypervisor-source"
        temporary_dir = extraction_dir.with_name(
            f".{extraction_dir.name}-extracting"
        )
        shutil.rmtree(temporary_dir, ignore_errors=True)
        temporary_dir.mkdir(parents=True)

        try:
            with zipfile.ZipFile(archive) as source_zip:
                for entry in source_zip.infolist():
                    entry_path = Path(entry.filename)
                    if (
                        entry_path.is_absolute()
                        or ".." in entry_path.parts
                        or (entry.external_attr >> 16) & 0o170000 == 0o120000
                    ):
                        raise ValueError(
                            "The ZIP file contains an unsafe path or symbolic link."
                        )
                source_zip.extractall(temporary_dir)

            candidates = [temporary_dir]
            candidates.extend(
                path
                for path in temporary_dir.iterdir()
                if path.is_dir()
            )
            source_root = next(
                (
                    candidate
                    for candidate in candidates
                    if (candidate / "Makefile").is_file()
                ),
                None,
            )
            if source_root is None:
                raise ValueError(
                    "The ZIP file does not contain a Makefile at its root "
                    "or in its top-level folder."
                )

            relative_source = source_root.relative_to(temporary_dir)
            shutil.rmtree(extraction_dir, ignore_errors=True)
            temporary_dir.replace(extraction_dir)
            candidate = (extraction_dir / relative_source).resolve()

            user_home = getattr(decky, "DECKY_USER_HOME", None)
            if os.geteuid() == 0 and user_home:
                owner = Path(user_home).stat()
                for extracted_path in [extraction_dir, *extraction_dir.rglob("*")]:
                    os.chown(extracted_path, owner.st_uid, owner.st_gid)

            settings = self.config
            settings["source_dir"] = str(candidate)
            self._save_config(settings)
        except (OSError, zipfile.BadZipFile) as error:
            shutil.rmtree(temporary_dir, ignore_errors=True)
            raise ValueError(f"Could not extract the ZIP file: {error}") from error
        except Exception:
            shutil.rmtree(temporary_dir, ignore_errors=True)
            raise

        self._last_log = f"Extracted hypervisor ZIP to: {candidate}"
        return await self.get_status()

    @property
    def kernel_release(self) -> str:
        return os.uname().release

    @property
    def headers_dir(self) -> Path:
        return Path("/lib/modules") / self.kernel_release / "build"

    @property
    def kernel_compiler(self) -> str:
        try:
            version = Path("/proc/version").read_text(encoding="utf-8").lower()
        except OSError:
            version = ""
        return "clang" if "clang" in version else "gcc"

    @property
    def compiler_name(self) -> str:
        configured = self.config.get("compiler", "auto")
        if configured not in ("auto", "gcc", "clang"):
            raise ValueError("compiler must be auto, gcc, or clang")
        return self.kernel_compiler if configured == "auto" else configured

    def _require_root(self) -> None:
        if os.geteuid() != 0:
            raise PermissionError(
                "The backend is not running as root."
            )

    def _manual_module_paths(self) -> list[Path]:
        module = self.source_dir / self.MODULE_FILE
        return [module] if module.is_file() else []

    def _automatic_module_paths(self) -> list[Path]:
        module = self.automatic_module_path
        return [module] if module.is_file() else []

    def _module_paths(self) -> list[Path]:
        return [*self._automatic_module_paths(), *self._manual_module_paths()]

    def _configured_manual_module_path(self) -> Path | None:
        module = self.source_dir / self.MODULE_FILE
        return module if module.is_file() else None

    def _configured_automatic_module_path(self) -> Path | None:
        module = self.automatic_module_path
        return module if module.is_file() else None

    @staticmethod
    def _jupiter_repository() -> str:
        try:
            pacman_conf = Path("/etc/pacman.conf").read_text(encoding="utf-8")
        except OSError:
            raise ValueError(
                "Could not read /etc/pacman.conf to determine the Jupiter repository."
            )

        for raw_line in pacman_conf.splitlines():
            line = raw_line.strip().lower()
            match = re.fullmatch(r"\[(jupiter-[^\]]+)\]", line)
            if match:
                repo_name = match.group(1)
                return (
                    "https://steamdeck-packages.steamos.cloud/"
                    f"archlinux-mirror/{repo_name}/os/x86_64/"
                )

        raise ValueError(
            "Could not find a Jupiter repository entry in /etc/pacman.conf."
        )

    @property
    def build_user(self) -> str | None:
        try:
            uid = self.source_dir.stat().st_uid
            if uid == 0:
                user_home = getattr(decky, "DECKY_USER_HOME", None)
                if user_home:
                    uid = Path(user_home).stat().st_uid
            if uid == 0:
                return None
            return pwd.getpwuid(uid).pw_name
        except (KeyError, OSError):
            return None

    def umip_disabled(self) -> bool:
        try:
            with open("/proc/cpuinfo", "r", encoding="utf-8") as cpuinfo:
                return not any(
                    "umip" in line.lower() for line in cpuinfo if line.strip()
                )
        except OSError:
            pass
        return False

    async def _run(
        self,
        *command: str,
        cwd: Path | None = None,
        capture_log: bool = True,
    ) -> tuple[int, str]:
        decky.logger.info("Running privileged command: %s", " ".join(command))
        environment = os.environ.copy()
        environment.pop("LD_LIBRARY_PATH", None)
        environment.pop("LD_PRELOAD", None)
        environment["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin"
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(cwd) if cwd else None,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            env=environment,
        )
        stdout, _ = await process.communicate()
        output = stdout.decode("utf-8", errors="replace").strip()
        if capture_log:
            self._last_log = output[-12000:]
        return process.returncode, output

    async def _module_name(self, module_path: Path) -> str:
        modinfo = shutil.which("modinfo")
        if modinfo:
            code, output = await self._run(
                modinfo,
                "-F",
                "name",
                str(module_path),
                capture_log=False,
            )
            if code == 0 and output.strip():
                return output.strip().splitlines()[-1]

        configured = self.config.get("module_name")
        if configured:
            return str(configured)
        return self.MODULE_NAME

    async def _running_kernel_release(self) -> str | None:
        uname = shutil.which("uname") or "/usr/bin/uname"
        code, output = await self._run(
            uname, "-r", capture_log=False
        )
        if code != 0:
            decky.logger.error("uname -r failed: %s", output)
            return None

        release = output.strip().splitlines()[-1] if output.strip() else ""
        if not release or not re.fullmatch(r"[a-zA-Z0-9._+:-]+", release):
            decky.logger.error("uname -r returned an invalid kernel release: %r", release)
            return None
        return release

    async def _kernel_package(self, kernel_release: str) -> str | None:
        pacman = shutil.which("pacman")
        if not pacman:
            return None
        candidates = [
            Path("/usr/lib/modules") / kernel_release / "vmlinuz",
            Path("/usr/lib/modules") / kernel_release,
        ]
        for candidate in candidates:
            code, output = await self._run(
                pacman, "-Qqo", str(candidate), capture_log=False
            )
            if code == 0 and output.strip():
                package = output.strip().splitlines()[0]
                if re.fullmatch(r"[a-zA-Z0-9@._+:-]+", package):
                    return package
        return None

    @staticmethod
    def _headers_filename(
        repository_index: str,
        kernel_package: str,
        kernel_release: str,
    ) -> str | None:
        release_suffix = kernel_package.removeprefix("linux-")
        release_match = re.fullmatch(
            rf"(?P<version>.+)-(?P<pkgrel>\d+(?:\.\d+)?)-"
            rf"{re.escape(release_suffix)}(?:-g[0-9a-fA-F]+)?",
            kernel_release,
        )
        if not release_match:
            return None

        package_version = release_match.group("version").replace(
            "-valve", ".valve", 1
        )
        package_release = release_match.group("pkgrel")
        expected_filename = (
            f"{kernel_package}-headers-{package_version}-"
            f"{package_release}-x86_64.pkg.tar.zst"
        )
        filenames = {
            urllib.parse.unquote(match)
            for match in re.findall(
                r"""href=["']([^"'?#]+)["']""",
                repository_index,
                flags=re.IGNORECASE,
            )
        }
        if expected_filename in filenames:
            return expected_filename

        xz_filename = expected_filename.removesuffix(".zst") + ".xz"
        return xz_filename if xz_filename in filenames else None

    async def _headers_package_url(self) -> str | None:
        kernel_release = await self._running_kernel_release()
        if not kernel_release:
            return None

        kernel_package = await self._kernel_package(kernel_release)
        if not kernel_package:
            return None

        curl = shutil.which("curl")
        if not curl:
            decky.logger.error("curl is required to read the SteamOS package repo")
            return None

        repository = self._jupiter_repository()

        code, repository_index = await self._run(
            curl,
            "-fsSL",
            "--max-time",
            "20",
            repository,
            capture_log=False,
        )

        filename = self._headers_filename(
            repository_index,
            kernel_package,
            kernel_release,
        )
        if not filename:
            return None
        return urllib.parse.urljoin(repository, filename)

    @staticmethod
    def _is_steamos() -> bool:
        try:
            values = Path("/etc/os-release").read_text(
                encoding="utf-8"
            ).lower()
        except OSError:
            return False
        return "steamos" in values

    @staticmethod
    def _loaded_modules() -> set[str]:
        try:
            return {
                line.split()[0]
                for line in Path("/proc/modules").read_text(encoding="utf-8").splitlines()
                if line.strip()
            }
        except OSError:
            return set()

    @staticmethod
    def _vdf_value(contents: str, key: str) -> str | None:
        match = re.search(
            rf'"{re.escape(key)}"\s+"((?:\\.|[^"\\])*)"',
            contents,
            flags=re.IGNORECASE,
        )
        if not match:
            return None
        return re.sub(r"\\([\\\"])", r"\1", match.group(1))

    def _steam_library_paths(self) -> list[Path]:
        home = Path(str(getattr(decky, "DECKY_USER_HOME", "/home/deck")))
        roots = [
            home / ".steam" / "root",
            home / ".steam" / "steam",
            home / ".local" / "share" / "Steam",
        ]
        libraries: list[Path] = []
        seen: set[str] = set()

        def add_library(path: Path) -> None:
            steamapps = path if path.name == "steamapps" else path / "steamapps"
            key = str(steamapps.resolve())
            if steamapps.is_dir() and key not in seen:
                seen.add(key)
                libraries.append(steamapps)

        for root in roots:
            add_library(root)
            library_file = root / "steamapps" / "libraryfolders.vdf"
            try:
                contents = library_file.read_text(encoding="utf-8")
            except OSError:
                continue
            pairs = re.findall(
                r'"([^"\\]+)"\s+"((?:\\.|[^"\\])*)"', contents
            )
            for key, raw_path in pairs:
                if key.lower() != "path" and not key.isdigit():
                    continue
                value = re.sub(r"\\([\\\"])", r"\1", raw_path)
                if "/" in value or "\\" in value:
                    add_library(Path(value))
        return libraries

    def _installed_games(
        self, shortcut_parse_log: list[str] | None = None
    ) -> list[dict[str, Any]]:
        enabled_values = self.config.get("game_hv", {})
        enabled = enabled_values if isinstance(enabled_values, dict) else {}
        games: dict[str, dict[str, Any]] = {}
        for steamapps in self._steam_library_paths():
            for manifest in steamapps.glob("appmanifest_*.acf"):
                try:
                    contents = manifest.read_text(encoding="utf-8")
                except OSError:
                    continue
                app_id = self._vdf_value(contents, "appid")
                name = self._vdf_value(contents, "name")
                if not app_id or not app_id.isdigit() or not name:
                    continue
                games[app_id] = {
                    "app_id": app_id,
                    "name": name,
                    "hv_enabled": enabled.get(app_id) is True,
                    "running": app_id in self._running_game_ids,
                    "non_steam": False,
                }
        for shortcut in self._steam_shortcuts(shortcut_parse_log):
            app_id = shortcut["app_id"]
            games[app_id] = {
                **shortcut,
                "hv_enabled": enabled.get(app_id) is True,
                "running": app_id in self._running_game_ids,
                "non_steam": True,
            }
        return sorted(games.values(), key=lambda game: game["name"].casefold())

    @staticmethod
    def _binary_vdf_string(data: bytes, position: int) -> tuple[str, int]:
        end = data.find(b"\0", position)
        if end < 0:
            raise ValueError("Unterminated string in binary VDF file")
        return data[position:end].decode("utf-8", errors="replace"), end + 1

    @classmethod
    def _binary_vdf_object(
        cls, data: bytes, position: int = 0
    ) -> tuple[dict[str, Any], int]:
        result: dict[str, Any] = {}
        while position < len(data):
            value_type = data[position]
            position += 1
            if value_type in (8, 10):
                return result, position
            key, position = cls._binary_vdf_string(data, position)
            if value_type == 0:
                value, position = cls._binary_vdf_object(data, position)
            elif value_type == 1:
                value, position = cls._binary_vdf_string(data, position)
            elif value_type in (2, 3, 4, 6):
                if position + 4 > len(data):
                    raise ValueError("Truncated binary VDF value")
                value = struct.unpack_from("<I", data, position)[0]
                position += 4
            elif value_type in (7, 9):
                if position + 8 > len(data):
                    raise ValueError("Truncated binary VDF value")
                value = struct.unpack_from("<Q", data, position)[0]
                position += 8
            elif value_type == 5:
                end = data.find(b"\0\0", position)
                if end < 0:
                    raise ValueError("Unterminated wide string in binary VDF file")
                if (end - position) % 2:
                    end += 1
                value = data[position:end].decode("utf-16-le", errors="replace")
                position = end + 2
            else:
                raise ValueError(f"Unsupported binary VDF type {value_type}")
            result[key] = value
        return result, position

    def _steam_shortcuts(
        self, parse_log: list[str] | None = None
    ) -> list[dict[str, str]]:
        home = Path(str(getattr(decky, "DECKY_USER_HOME", "/home/deck")))
        steam_roots = {
            home / ".steam" / "root",
            home / ".steam" / "steam",
            home / ".local" / "share" / "Steam",
        }
        shortcuts: dict[str, dict[str, str]] = {}
        files: set[Path] = set()
        for root in steam_roots:
            userdata = root / "userdata"
            if userdata.is_dir():
                files.update(
                    shortcut_file.resolve()
                    for shortcut_file in userdata.glob("*/config/shortcuts.vdf")
                )
        configured_file = str(self.config.get("shortcuts_file", "")).strip()
        if configured_file:
            files.add(Path(configured_file).expanduser().resolve())

        for shortcut_file in sorted(files):
            try:
                parsed, _ = self._binary_vdf_object(shortcut_file.read_bytes())
                entries = parsed.get("shortcuts", {})
                if not isinstance(entries, dict):
                    if parse_log is not None:
                        parse_log.extend(
                            [f"File parsed: {shortcut_file}", "Found apps: 0"]
                        )
                    continue
                found_names: list[str] = []
                for entry in entries.values():
                    if not isinstance(entry, dict):
                        continue
                    normalized_entry = {
                        key.casefold(): value
                        for key, value in entry.items()
                        if isinstance(key, str)
                    }
                    app_id = normalized_entry.get("appid")
                    name = normalized_entry.get("appname")
                    if isinstance(app_id, int) and isinstance(name, str) and name:
                        shortcuts[str(app_id)] = {
                            "app_id": str(app_id),
                            "name": name,
                        }
                        found_names.append(name)
                if parse_log is not None:
                    parse_log.extend(
                        [
                            f"File parsed: {shortcut_file}",
                            f"Found apps: {len(found_names)}"
                            + (f" ({', '.join(found_names)})" if found_names else ""),
                        ]
                    )
            except (OSError, ValueError, struct.error) as error:
                decky.logger.warning(
                    "Could not read Steam shortcuts from %s: %s",
                    shortcut_file,
                    error,
                )
                if parse_log is not None:
                    parse_log.append(
                        f"Could not parse file: {shortcut_file}\nReason: {error}"
                    )
        return list(shortcuts.values())

    @staticmethod
    def _running_steam_games() -> set[str]:
        running: set[str] = set()
        try:
            processes = Path("/proc").iterdir()
        except OSError:
            return running

        for process in processes:
            if not process.name.isdigit():
                continue
            try:
                environment = (process / "environ").read_bytes().split(b"\0")
            except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
                continue
            for entry in environment:
                key, separator, value = entry.partition(b"=")
                if not separator or key not in {
                    b"SteamAppId",
                    b"SteamGameId",
                    b"PRESSURE_VESSEL_APP_ID",
                }:
                    continue
                app_id = value.decode("ascii", errors="ignore")
                if app_id.isdigit() and app_id != "0":
                    numeric_id = int(app_id)
                    shortcut_id = numeric_id >> 32
                    if shortcut_id & 0x80000000:
                        running.add(str(shortcut_id))
                    else:
                        running.add(app_id)
        return running

    def _game_hv_ids(self) -> set[str]:
        values = self.config.get("game_hv", {})
        if not isinstance(values, dict):
            return set()
        return {
            str(app_id)
            for app_id, enabled in values.items()
            if enabled is True and str(app_id).isdigit()
        }

    def _module_candidates(self) -> list[Path]:
        return [
            path
            for path in (
                self._configured_automatic_module_path(),
                self._configured_manual_module_path(),
            )
            if path is not None
        ]

    async def set_game_hv(self, app_id: str, enabled: bool) -> dict[str, Any]:
        if not str(app_id).isdigit():
            raise ValueError("The Steam app ID is invalid.")
        settings = self.config
        values = settings.get("game_hv", {})
        game_hv = dict(values) if isinstance(values, dict) else {}
        if enabled:
            game_hv[str(app_id)] = True
        else:
            game_hv.pop(str(app_id), None)
        settings["game_hv"] = game_hv
        self._save_config(settings)
        await self._reconcile_game_hv()
        return await self.get_status()

    async def refresh_games(self) -> dict[str, Any]:
        async with self._operation_lock:
            parse_log: list[str] = []
            games = self._installed_games(parse_log)
            message = "Games list refreshed."
            if parse_log:
                message += "\n" + "\n".join(parse_log)
            else:
                message += "\nNo shortcuts.vdf files were found."

            status = await self.get_status()
            self._last_log = message
            status["games"] = games
            status["last_log"] = message
            return status

    async def set_shortcuts_file(self, path: str) -> dict[str, Any]:
        candidate = Path(path).expanduser().resolve()
        if not candidate.is_file():
            raise ValueError("The selected shortcuts file does not exist.")
        if candidate.suffix.casefold() != ".vdf":
            raise ValueError("Please select a shortcuts.vdf file.")

        async with self._operation_lock:
            settings = self.config
            settings["shortcuts_file"] = str(candidate)
            self._save_config(settings)

            parse_log: list[str] = []
            games = self._installed_games(parse_log)
            message = "Selected shortcuts file."
            if parse_log:
                message += "\n" + "\n".join(parse_log)

            status = await self.get_status()
            self._last_log = message
            status["games"] = games
            status["shortcuts_file"] = str(candidate)
            status["last_log"] = message
            return status

    async def update_game_lifetime(
        self, app_id: str, instance_id: int, running: bool
    ) -> None:
        app_id = str(app_id)
        if not app_id.isdigit():
            return
        if app_id == "0":
            shortcut_ids = {
                shortcut["app_id"] for shortcut in self._steam_shortcuts()
            }
            previous = self._running_game_ids & shortcut_ids
            attempts = 4 if running else 1
            detected: set[str] = set()
            for attempt in range(attempts):
                detected = self._running_steam_games() & shortcut_ids
                if not running or detected != previous or attempt == attempts - 1:
                    break
                await asyncio.sleep(0.5)
            self._running_game_ids.difference_update(shortcut_ids)
            self._running_game_ids.update(detected)
            await self._reconcile_game_hv()
            return
        if running:
            self._running_game_instances.setdefault(app_id, set()).add(instance_id)
            self._running_game_ids.add(app_id)
        else:
            instances = self._running_game_instances.get(app_id)
            if instances is not None:
                instances.discard(instance_id)
                if instances:
                    return
                self._running_game_instances.pop(app_id, None)
            self._running_game_ids.discard(app_id)
        await self._reconcile_game_hv()

    async def _reconcile_game_hv(self) -> None:
        async with self._operation_lock:
            should_load = bool(self._running_game_ids & self._game_hv_ids())
            if (
                self._watcher_module_name is not None
                and self._watcher_module_name not in self._loaded_modules()
            ):
                self._watcher_module_path = None
                self._watcher_module_name = None
            if should_load and self._watcher_module_name is None:
                try:
                    module_paths = self._module_candidates()
                except (RuntimeError, ValueError) as error:
                    self._last_log = str(error)
                    return
                if not module_paths:
                    self._last_log = (
                        "An HV-enabled game is running, but no downloaded or "
                        "built module is available."
                    )
                    return
                for module_path in module_paths:
                    name = await self._module_name(module_path)
                    if name in self._loaded_modules():
                        return
                    result = await self._load_module_path(
                        module_path,
                        "Download or build the module before launching this game.",
                    )
                    if result["ok"] and name in self._loaded_modules():
                        self._watcher_module_path = module_path
                        self._watcher_module_name = name
                        decky.logger.info("Loaded %s for an HV-enabled game", name)
                        break
                else:
                    decky.logger.error(
                        "Could not load HV module for a game: %s", result["message"]
                    )
            elif not should_load and self._watcher_module_name is not None:
                path = self._watcher_module_path
                name = self._watcher_module_name
                result = await self._unload_module_path(
                    path,
                    "The game-managed module path is no longer available.",
                )
                if result["ok"] or name not in self._loaded_modules():
                    self._watcher_module_path = None
                    self._watcher_module_name = None
                    decky.logger.info("Stopped %s after the game exited", name)
                else:
                    decky.logger.error(
                        "Could not stop game-managed HV module: %s", result["message"]
                    )

    async def get_status(self) -> dict[str, Any]:
        loaded = self._loaded_modules()
        automatic_module_info = []
        for path in self._automatic_module_paths():
            name = await self._module_name(path)
            automatic_module_info.append(
                {
                    "path": str(path),
                    "name": name,
                    "loaded": name in loaded,
                }
            )

        manual_module_info = []
        for path in self._manual_module_paths():
            name = await self._module_name(path)
            manual_module_info.append(
                {
                    "path": str(path),
                    "name": name,
                    "loaded": name in loaded,
                }
            )

        configured_manual_module = None
        try:
            selected = self._configured_manual_module_path()
            configured_manual_module = str(selected) if selected else None
        except (RuntimeError, ValueError) as error:
            self._last_log = str(error)

        configured_automatic_module = None
        selected = self._configured_automatic_module_path()
        configured_automatic_module = str(selected) if selected else None

        try:
            compiler_name = self.compiler_name
            compiler_error = ""
        except ValueError as error:
            compiler_name = self.kernel_compiler
            compiler_error = str(error)
            self._last_log = compiler_error

        return {
            "root": os.geteuid() == 0,
            "kernel_release": self.kernel_release,
            "umip_disabled": self.umip_disabled(),
            "architecture": os.uname().machine,
            "headers_path": str(self.headers_dir),
            "headers_ready": (
                self.headers_dir.is_dir()
                and (self.headers_dir / "Makefile").is_file()
            ),
            "make_path": shutil.which("make"),
            "gcc_path": shutil.which("gcc"),
            "clang_path": shutil.which("clang"),
            "kernel_compiler": self.kernel_compiler,
            "compiler_name": compiler_name,
            "compiler_path": shutil.which(compiler_name),
            "compiler_error": compiler_error,
            "source_path": str(self.source_dir),
            "source_ready": (
                self.source_dir.is_dir()
                and (self.source_dir / "Makefile").is_file()
            ),
            "build_user": self.build_user,
            "expected_module": self.MODULE_FILE,
            "is_steamos": self._is_steamos(),
            "pacman_path": shutil.which("pacman"),
            "modinfo_path": shutil.which("modinfo"),
            "insmod_path": shutil.which("insmod"),
            "rmmod_path": shutil.which("rmmod"),
            "modules": [*automatic_module_info, *manual_module_info],
            "automatic_modules": automatic_module_info,
            "manual_modules": manual_module_info,
            "configured_module": configured_manual_module,
            "configured_automatic_module": configured_automatic_module,
            "automatic_module_path": str(self.automatic_module_path),
            "games": self._installed_games(),
            "shortcuts_file": str(self.config.get("shortcuts_file", "")),
            "last_log": self._last_log,
        }

    async def _result(
        self,
        ok: bool,
        message: str,
        output: str = "",
        reboot_required: bool = False,
    ) -> dict[str, Any]:
        return {
            "ok": ok,
            "message": message,
            "output": output,
            "reboot_required": reboot_required,
            "status": await self.get_status(),
        }

    async def build_module(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            make = shutil.which("make")
            try:
                compiler_name = self.compiler_name
            except ValueError as error:
                return await self._result(False, str(error))
            compiler = shutil.which(compiler_name)
            if not make or not compiler:
                return await self._result(
                    False,
                    f"make and {compiler_name} must both be installed.",
                )
            if not self.headers_dir.is_dir() or not (
                self.headers_dir / "Makefile"
            ).is_file():
                return await self._result(
                    False,
                    f"Matching kernel headers are missing: {self.headers_dir}",
                )
            if not (self.source_dir / "Makefile").is_file():
                return await self._result(
                    False, f"No Makefile found in {self.source_dir}"
                )

            make_args = self.config.get("make_args", [])
            if not isinstance(make_args, list) or not all(
                isinstance(arg, str) for arg in make_args
            ):
                return await self._result(
                    False, "Saved make_args must be a list of strings."
                )

            toolchain_args = [f"CC={compiler}"]
            if compiler_name == "clang":
                toolchain_args.append("LLVM=1")

            build_user = self.build_user
            runuser = shutil.which("runuser")
            if os.geteuid() == 0:
                if not build_user or not runuser:
                    return await self._result(
                        False,
                        "Could not identify a non-root user for the build. "
                        "The plugin will not execute a selected Makefile as root.",
                    )
                command = [
                    runuser,
                    "--user",
                    build_user,
                    "--",
                    make,
                ]
            else:
                command = [make]

            code, output = await self._run(
                *command,
                "-C",
                str(self.source_dir),
                *toolchain_args,
                *make_args,
            )

            try:
                selected = self._configured_manual_module_path()
            except (RuntimeError, ValueError) as error:
                return await self._result(False, str(error), output)
            if selected is None:
                return await self._result(
                    False, "Build completed but produced no .ko file.", output
                )
            return await self._result(
                True, f"Built {selected.name} for {self.kernel_release}.", output
            )

    async def install_build_dependencies(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()

            pacman = shutil.which("pacman")
            pacman_key = shutil.which("pacman-key")
            readonly = shutil.which("steamos-readonly")
            if not pacman or not pacman_key:
                return await self._result(
                    False, "SteamOS pacman or pacman-key was not found."
                )

            packages = ["gcc", "make", "kmod"]
            if self.compiler_name == "clang":
                packages.append("clang")

            headers_url = None
            if not (
                self.headers_dir.is_dir()
                and (self.headers_dir / "Makefile").is_file()
            ):
                try:
                    headers_url = await self._headers_package_url()
                except ValueError as error:
                    return await self._result(False, str(error))
                if not headers_url:
                    kernel_release = await self._running_kernel_release()
                    kernel_package = (
                        await self._kernel_package(kernel_release)
                        if kernel_release
                        else None
                    )
                    detail = (
                        f"Kernel package: {kernel_package}."
                        if kernel_package
                        else "The running kernel package could not be identified."
                    )
                    return await self._result(
                        False,
                        "Could not find an exact headers archive for "
                        f"{self.kernel_release}. {detail} Update/reboot SteamOS "
                        "or install matching headers manually.",
                    )

            readonly_was_enabled = False
            output_parts: list[str] = []
            try:
                if readonly:
                    code, output = await self._run(
                        readonly, "status", capture_log=False
                    )
                    output_parts.append(output)
                    readonly_was_enabled = (
                        code == 0 and "enabled" in output.lower()
                    )
                    if readonly_was_enabled:
                        code, output = await self._run(readonly, "disable")
                        output_parts.append(output)

                code, output = await self._run(pacman_key, "--init")
                output_parts.append(output)

                code, output = await self._run(pacman_key, "--populate")
                output_parts.append(output)

                code, output = await self._run(
                    pacman,
                    "-S",
                    "--needed",
                    "--noconfirm",
                    *packages,
                )
                output_parts.append(output)

                if headers_url:
                    code, output = await self._run(
                        pacman,
                        "-U",
                        "--needed",
                        "--noconfirm",
                        headers_url,
                    )
                    output_parts.append(output)
                    if code != 0:
                        return await self._result(
                            False,
                            "pacman failed while installing kernel headers from "
                            f"{headers_url}",
                            "\n".join(output_parts),
                        )
            finally:
                if readonly and readonly_was_enabled:
                    code, output = await self._run(readonly, "enable")
                    output_parts.append(output)
                    if code != 0:
                        decky.logger.error(
                            "Failed to restore SteamOS read-only mode"
                        )

            return await self._result(
                True,
                f"Build dependencies are ready: {' '.join(packages)}",
                "\n".join(output_parts),
            )
    
    async def disable_umip(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            reboot_required = False
            if not self.umip_disabled():
                grub_config = Path("/etc/default/grub")
                if not grub_config.is_file():
                    return await self._result(
                        False,
                        "Grub configuration file not found.",
                    )
                grub_content = grub_config.read_text(encoding="utf-8")
                if "clearcpuid=514" not in grub_content:
                    # yay regex
                    grub_content = re.sub(
                        r'GRUB_CMDLINE_LINUX_DEFAULT="([^"]*)"',
                        r'GRUB_CMDLINE_LINUX_DEFAULT="\1 clearcpuid=514"',
                        grub_content,
                    )
                    grub_config.write_text(grub_content, encoding="utf-8")
                    update_grub = shutil.which("update-grub")
                    if not update_grub:
                        return await self._result(
                            False,
                            "Grub update command not found.",
                        )
                    code, output = await self._run(update_grub)
                    if code != 0:
                        return await self._result(
                            False,
                            "Failed to update Grub configuration.",
                            output,
                        )
                    reboot_required = True

            return await self._result(
                True,
                "UMIP is disabled.",
                reboot_required=reboot_required,
            )

    async def reboot_system(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            systemctl = shutil.which("systemctl")
            if not systemctl:
                return await self._result(False, "systemctl was not found.")

            code, output = await self._run(systemctl, "reboot")
            if code != 0:
                return await self._result(
                    False,
                    "Failed to reboot the system.",
                    output,
                )
            return await self._result(True, "Rebooting now.", output)
        
    async def download_bin(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            module_path = self._configured_automatic_module_path()
            if module_path is not None and module_path.is_file():
                return await self._result(
                    True,
                    f"Module already exists at {module_path}.",
                )

            curl = shutil.which("curl")
            wget = shutil.which("wget")
            if not curl:
                return await self._result(False, "curl was not found.")
            if not wget:
                return await self._result(False, "wget was not found.")

            code, release_json = await self._run(
                curl,
                "-fsSL",
                self.RELEASE_API_URL,
                capture_log=False,
            )
            if code != 0:
                return await self._result(
                    False,
                    f"Failed to query {self.RELEASE_API_URL}.",
                    release_json,
                )

            expected_asset = f"cpuid_fault_emulation-{self.kernel_release}.ko"
            try:
                release = json.loads(release_json)
                assets = release.get("assets", [])
                if not isinstance(assets, list):
                    raise ValueError("release assets were not a list")
                download_url = next(
                    (
                        str(asset["browser_download_url"])
                        for asset in assets
                        if isinstance(asset, dict)
                        and asset.get("name") == expected_asset
                        and isinstance(asset.get("browser_download_url"), str)
                    ),
                    None,
                )
            except (json.JSONDecodeError, KeyError, ValueError) as error:
                return await self._result(
                    False,
                    f"Could not parse GitHub release metadata: {error}",
                    release_json,
                )

            if not download_url:
                available = [
                    str(asset.get("name"))
                    for asset in assets
                    if isinstance(asset, dict)
                    and isinstance(asset.get("name"), str)
                    and str(asset.get("name")).endswith(".ko")
                ]
                detail = (
                    f" Available modules: {', '.join(available[:12])}."
                    if available
                    else ""
                )
                return await self._result(
                    False,
                    f"No prebuilt module named {expected_asset} was found in "
                    f"the latest release.{detail}",
                )

            self.automatic_module_dir.mkdir(parents=True, exist_ok=True)
            temporary_path = self.automatic_module_path.with_suffix(".ko.tmp")
            code, output = await self._run(
                wget,
                "-O",
                str(temporary_path),
                download_url,
            )
            if code != 0:
                try:
                    temporary_path.unlink()
                except FileNotFoundError:
                    pass
                except OSError as error:
                    decky.logger.warning(
                        "Failed to remove partial module download: %s", error
                    )
            if code != 0:
                return await self._result(
                    False,
                    f"Failed to download the module from {download_url}.",
                    output,
                )
            temporary_path.replace(self.automatic_module_path)
            return await self._result(
                True,
                f"Downloaded module to {self.automatic_module_path}.",
                output,
            )

    async def _load_module_path(
        self,
        module_path: Path | None,
        missing_message: str,
    ) -> dict[str, Any]:
        if module_path is None:
            return await self._result(False, missing_message)

        name = await self._module_name(module_path)
        if name in self._loaded_modules():
            return await self._result(True, f"{name} is already loaded.")

        modinfo = shutil.which("modinfo")
        if not modinfo:
            return await self._result(
                False,
                "modinfo is unavailable. Install the kmod package before loading.",
            )
        code, vermagic = await self._run(
            modinfo,
            "-F",
            "vermagic",
            str(module_path),
            capture_log=False,
        )
        if code != 0 or self.kernel_release not in vermagic:
            return await self._result(
                False,
                "The module was not built for the running kernel "
                f"{self.kernel_release}. Rebuild it before starting.",
            )

        insmod = shutil.which("insmod")
        if not insmod:
            return await self._result(False, "kmod is not installed.")
        
        modprobe = shutil.which("modprobe")

        if modprobe:
            code, output = await self._run(modprobe, "-r", "kvm_amd")
            code, output = await self._run(modprobe, "-r", "kvm")

        code, output = await self._run(insmod, str(module_path))
        if code != 0:
            return await self._result(
                False, f"insmod exited with code {code}", output
            )
        return await self._result(True, f"Loaded {name}.", output)

    async def load_module(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            try:
                module_path = self._configured_manual_module_path()
            except (RuntimeError, ValueError) as error:
                return await self._result(False, str(error))
            return await self._load_module_path(
                module_path,
                "Build the module before starting it.",
            )

    async def load_automatic_module(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            module_path = self._configured_automatic_module_path()
            return await self._load_module_path(
                module_path,
                "Download the module before starting it.",
            )

    async def _unload_module_path(
        self,
        module_path: Path | None,
        missing_message: str,
    ) -> dict[str, Any]:
        if module_path is None:
            return await self._result(False, missing_message)

        name = await self._module_name(module_path)
        if name not in self._loaded_modules():
            return await self._result(True, f"{name} is already stopped.")

        rmmod = shutil.which("rmmod")
        if not rmmod:
            return await self._result(False, "kmod is not installed.")
        code, output = await self._run(rmmod, name)
        if code != 0:
            return await self._result(
                False,
                f"rmmod exited with code {code}; the module may still be in use.",
                output,
            )
        modprobe = shutil.which("modprobe")

        if modprobe:
            code, output = await self._run(modprobe, "kvm_amd")
            code, output = await self._run(modprobe, "kvm")

        return await self._result(True, f"Unloaded {name}.", output)

    async def unload_module(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            try:
                module_path = self._configured_manual_module_path()
            except (RuntimeError, ValueError) as error:
                return await self._result(False, str(error))
            return await self._unload_module_path(
                module_path,
                "No built module was found.",
            )

    async def unload_automatic_module(self) -> dict[str, Any]:
        async with self._operation_lock:
            self._require_root()
            module_path = self._configured_automatic_module_path()
            return await self._unload_module_path(
                module_path,
                "No downloaded module was found.",
            )

    async def _main(self) -> None:
        decky.logger.info(
            "Hypervisor Manager started (uid=%s, kernel=%s)",
            os.geteuid(),
            self.kernel_release,
        )
        self._running_game_ids = self._running_steam_games()
        await self._reconcile_game_hv()

    async def _unload(self) -> None:
        if self._watcher_module_name is not None:
            async with self._operation_lock:
                result = await self._unload_module_path(
                    self._watcher_module_path,
                    "The game-managed module path is no longer available.",
                )
                if not result["ok"]:
                    decky.logger.error(
                        "Could not stop game-managed module during shutdown: %s",
                        result["message"],
                    )
            self._watcher_module_path = None
            self._watcher_module_name = None
        decky.logger.info("Hypervisor Manager backend stopped")
